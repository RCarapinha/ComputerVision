import cv2
import glob
import numpy as np
from itertools import izip
from PIL import Image
import sys
from scipy.misc import imread
from scipy.linalg import norm
from scipy import sum, average

def Pixel():
	In1 = raw_input("1 Image Name -> ")
	i1 = Image.open(In1 + ".jpg")

	In2 = raw_input("2 Image Name -> ")
	i2 = Image.open(In2 + ".jpg")

	width1, height1 = i1.size
	width2, height2 = i2.size

	if width1 <= width2:
		width = width1
	else:
		width = width2

	if height1 <= height2:
		height = height1
	else:
		height = height2

	I1 = i1.resize((width,height))
	I2 = i2.resize((width,height))

	randPix = I1.getpixel((0,0))
        maxSum = []
        diff = []
        for channel in range(len(randPix)):
            diff += [0.0]
            maxSum += [0.0]
        width = I1.size[0]
        height = I1.size[1]
        for i in range(width):
            for j in range(height):
                pixel1 = I1.getpixel((i,j))
                pixel2 = I2.getpixel((i,j))
                for channel in range(len(randPix)):
                    maxSum[channel] += 255
                    diff[channel] += abs(pixel1[channel] - pixel2[channel])
        ret = ()
        for channel in range(len(randPix)):
        	ret += (diff[channel]/maxSum[channel],)
        print "Differences(%): ", ret[0]*100
       

def Snapshot(img, num, nm):
        cv2.imwrite(nm+".jpg",img)

def main():
	faceCascade = cv2.CascadeClassifier('/home/carapinha/Desktop/Face/haarcascade_frontalface_default.xml')
	cam = cv2.VideoCapture(0)
	num = 0;
	while True:
		ret_val, img = cam.read()
		gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		faces = faceCascade.detectMultiScale(gray, 1.3, 5)

		for (x,y,w,h) in faces:
			cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
			roi_color = img[y:y+h, x:x+w]

		cv2.imshow('Webcam', img)
		if cv2.waitKey(1) == 27: 
			break
		if cv2.waitKey(33) == ord(' '):
			Name = raw_input("Save as -> ")
			Snapshot(roi_color, num, Name)
			print "Image Saved -> " + str(num)
			num = num + 1
		if cv2.waitKey(33) == ord('a'):
			print(glob.glob('*.jpg'))
			Pixel()
	cam.release()	
	cv2.destroyAllWindows()

if __name__ == "__main__":
	main()
